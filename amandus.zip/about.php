<?php
    include 'header.php';
?>    
<script type="text/javascript">
    document.getElementById("om").className = "current";
</script>

<?php
    include 'footer.php';
?>
