$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+171793+'&oi='+66+'&ot=1&&url='+window.location, function(json){})    

});