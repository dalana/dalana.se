$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+171791+'&oi='+67+'&ot=1&&url='+window.location, function(json){})    

});