    </div> <!-- end of main -->
<div style="height: 10px"></div>
</div> <!-- end of wrap -->
		
<div id="footer">
    	<span>Copyright © 2013 <a href="#">Dalana Lan Orsa</a> - 
        Designed by Jimmy</span>
</div>


</body>
</html>
