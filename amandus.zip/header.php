<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Dalana Lan</title>
<meta name="description" content="Om du blir en fisk ska du ha samlag med pingviner." />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/png" href="/favicon.png" />
</head>
<body>
<div id="wrap">
	    
    <div id="header">
    
        <div id="site_title"><h1><a href="https://www.facebook.com/laniorsa">Amandus</a></h1></div>
                
    </div> <!-- end of templatemo header -->
  

    <div id="menu">
        <ul>
            <li><a href="index.php" id="hem">Hem</a></li>
            <li><a href="blog/" id="nyheter">Senaste nytt</a></li>
            <li><a href="portfolio.php" id="tavlingar">Tävlingar</a></li>
            <li><a href="about.php" id="om">Om oss</a></li>
            <li><a href="contact.php" id="kontakt">Kontakta oss</a></li>
        </ul>
    </div> <!-- end of templatemo_menu -->
    <div id="main">
