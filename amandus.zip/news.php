<?php
    include 'header.php';
?>    
<script type="text/javascript">
    document.getElementById("nyheter").className = "current";
</script>
    <div id="templatemo_main">
    
    	<div class="col_w620 float_l">
        	<div class="post_box">
            	<div class="post_header">
                    <p class="post_meta"><span class="cat">Posted in <a href="#">Web Templates</a>, <a href="#">CSS</a></span> | Date: June 28, 2048</p>
                    <h2>Sed mollis elementum lectus rhoncus</h2>
				</div>
                <a href="#"><img src="images/templatemo_image_06.jpg" alt="Image" /></a>
              <p>Wiktor är diktator <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                <a class="more" href="#">More</a>
                <div class="cleaner"></div>
            </div>
            <div class="post_box">
           	  <div class="post_header">
                <p class="post_meta"><span class="cat">Posted in <a href="#">Interfaces</a>, <a href="#">Web Design</a></span> | Date: June 24, 2048</p>
                <h2>Nunc varius venenatis sem sed</h2>
				</div>
                <a href="#"><img src="images/templatemo_image_07.jpg" alt="Image" /></a>
              <p> Aliquam erat volutpat. In pellentesque sagittis dictum. Aliquam erat volutpat. Donec ac aliquam neque. Sed tellus diam, consequat nec volutpat et, cursus ac nisi. Mauris in risus in diam consequat suscipit non ac enim.</p>
                <a href="http://pl.forwallpaper.com"   target="_blank" class="more">More</a>
                <div class="cleaner"></div>
            </div>
        </div>
        
        <div class="col_w300 float_r">
        	<h3>Categories</h3>
            <ul class="tmo_list">
            	<li>Etiam sit amet turpis</li>
                <li>Quisque ornare pulvinar lorem</li>
                <li><a href="#">Nullam lorem enim</a></li>
                <li>Phasellus ultrices justo</li>
                <li>Donec mattis rhoncus mi</li>
                <li>Quisque venenatis fringilla</li>
                <li><a href="#">Maecenas varius metus</a></li>
                <li>Donec mattis egestas sem</li>
            </ul>
          <div class="cleaner h30"></div>
        	
            <h3>Our News</h3>
            
            <div class="fp_news_box">
            	<img src="images/templatemo_image_02.jpg" alt="News One" />
                <h6><a href="http://pl.forwallpaper.com" class="no_link"   target="_blank">Quisque ornare pulvinar</a></h6>
                Aliquam lacus turpis, dapibus eget, tincidunt eu. Integer pellentesque dignissim.
                <div class="fp_news_date">June 28, 2048</div>
                <div class="cleaner"></div>
            </div>
            
            <div class="fp_news_box">
            	<img src="images/templatemo_image_03.jpg" alt="News Two" />
                <h6><a href="#">Nullam consectetur</a></h6>
              Nam id nibh quis nisi tristique pharetra a ut leo. Aenean vel lorem odio.
                <div class="fp_news_date">June 24, 2048</div>
                <div class="cleaner"></div>
            </div>
            
          	<a class="more" href="#">More</a>
            
            <div class="cleaner h30"></div>
            
            <h3>Testimonials</h3>
            <blockquote>
                <p>In quam nibh, placerat ac, porta ac, molestie non, purus. Nunc a nulla. Suspendisse vitae orci a ligula egestas bibendum. Vestibulum ultrices. Pellentesque tempus sapien nec sem commodo ullamcorper. Aenean neque. Cras feugiat. In ut ante.</p>
                <cite>Steven - <span>Web Designer</span></cite>
            </blockquote>
            
        </div>
        
        <div class="cleaner"></div>
    </div> <!-- end of main -->
<?php
    include 'footer.php';
?>
