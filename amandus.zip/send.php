<?php
   $to = 'amandus@dalana.se' ;     //put your email address on which you want to receive the information
   $subject = $_REQUEST['subject'] . " - dalana.se kontakt";
   $headers  = 'MIME-Version: 1.0' . "\r\n";
   $headers .= "Reply-To: " . $_REQUEST['email'] . "\r\n";
   $headers .= "From: " . $_REQUEST['author'] . " <21dalana12@gmail.com>\r\n";
   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
   $message = $_REQUEST['text'];
   mail($to, $subject, $message, $headers);
   header ('Location: contact.php');
?>
