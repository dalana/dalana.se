<?php
    include 'header.php';
?>        
<script type="text/javascript">
    document.getElementById("hem").className = "current";
</script>

<?php 
/* Short and sweet */
/*define('WP_USE_THEMES', false);*/
require('./blog/wp-blog-header.php');
?>

<?php
$posts = get_posts('numberposts=10&order=ASC&orderby=post_title');
foreach ($posts as $post) : setup_postdata( $post ); ?>
<?php the_date(); echo "<br />"; ?>
<?php the_title(); ?>    
<?php the_excerpt(); ?> 
<?php
endforeach;
?>

<?php
    include 'footer.php';
?>
